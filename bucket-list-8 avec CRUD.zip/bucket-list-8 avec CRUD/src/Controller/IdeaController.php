<?php

namespace App\Controller;

use App\Entity\Idea;
use App\Form\IdeaType;
use Doctrine\ORM\EntityManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class IdeaController extends AbstractController
{
    /**
     * @Route("/list", name="app_idea_list")
     */
    public function list(): Response 
    {

        $ideas = $this->getDoctrine()->getRepository(Idea::class);

        return $this->render('idea/list.html.twig', [
            'date' => getdate()["year"],
            'ideas' => $ideas->findLastIdeas()
        ]);
    }

    /**
     * @Route("/detail/{id}", 
     * name="app_idea_detail",
     * requirements={"page"="\d+"}, 
     * methods={"GET"})
     */
    public function detail($id): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $idea = $entityManager->getRepository(Idea::class)->findOneBy(["id" => $id]);

        return $this->render('idea/details.html.twig', [
            'date' => getdate()["year"],
            'idea' => $idea
        ]);    
    }

    /**
     * @Route("/delete/{id}",
     * name="app_idea_delete",
     * requirements={"page"="\d+"},
     * methods={"GET"})
     */
    public function delete($id): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $idea = $entityManager->getRepository(Idea::class)->findOneBy(["id" => $id, "author" => $this->getUser()->getUserIdentifier()]);

        if($idea == null) {
            $this->addFlash("danger", "Article has not been deleted because you are not the owner of article !");
        } else {
            $entityManager->remove($idea);
            $entityManager->flush();
            $this->addFlash("success", "Your idea has been deleted !");
        }

        return $this->redirectToRoute("app_idea_list");
    }

    /**
     * @Route("/edit/{id}",
     * name="app_idea_edit",
     * methods={"GET", "POST"})
     * @IsGranted("ROLE_USER")
     */
    public function edit($id, EntityManagerInterface $em, Request $request): Response
    {
        $idea = $em->getRepository(Idea::class)->findOneBy(["id" => $id, "author" => $this->getUser()->getUserIdentifier()]);

        if($idea == null) {
            $this->addFlash("danger", "You are not the writer of this article");
            return $this->redirectToRoute("home");
        }

        $form = $this->createForm(IdeaType::class, $idea);

        $form->setData($idea);

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

            $idea = $form->getData();

            $em->flush();

            $this->addFlash("success", "Idea has been updated !");
            return $this->redirectToRoute('app_idea_detail', ["id" => $idea->getId()]);
        }

        return $this->renderForm('idea/adding.html.twig', [
            'date' => getdate()["year"],
            'form' => $form
        ]);
    }

    /**
     * @Route("/add", 
     * name="app_idea_add",
     * methods={"GET", "POST"})
     * @IsGranted("ROLE_USER")
     */
    public function add(EntityManagerInterface $em, Request $request): Response
    {
        $idea = new Idea();
        $form = $this->createForm(IdeaType::class, $idea);

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

            $idea = $form->getData();
            $idea->setIsPublished(true);
            $idea->setDateCreated(new \DateTime());

            $em->persist($idea);
            $em->flush();

            $this->addFlash("success", "Idea has been added !");
            return $this->redirectToRoute('app_idea_detail', ["id" => $idea->getId()]);
        } else {
            $idea->setAuthor($this->getUser()->getUsername());
            $form->setData($idea);
        }


        return $this->renderForm('idea/adding.html.twig', [
            'date' => getdate()["year"],
            'form' => $form
        ]);    
    }

}
