<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class MainController extends AbstractController
{
    /**
     * @Route("/", name="home")
     */
    public function index(): Response
    {
        return $this->render("/bucket-list/home.html.twig", [
            "date" => getdate()["year"]
        ]);
    }

    /**
     * @Route("/aboutus", name="aboutus")
     */
    public function aboutus(): Response
    {
        return $this->render("/bucket-list/aboutus.html.twig", [
            "date" => getdate()["year"]
        ]);
    }
}
