<?php

namespace Container2YCajub;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder5d13b = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializeraadb4 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesd1f24 = [
        
    ];

    public function getConnection()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getConnection', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getMetadataFactory', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getExpressionBuilder', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'beginTransaction', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->beginTransaction();
    }

    public function getCache()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getCache', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getCache();
    }

    public function transactional($func)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'transactional', array('func' => $func), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'wrapInTransaction', array('func' => $func), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'commit', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->commit();
    }

    public function rollback()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'rollback', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getClassMetadata', array('className' => $className), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'createQuery', array('dql' => $dql), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'createNamedQuery', array('name' => $name), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'createQueryBuilder', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'flush', array('entity' => $entity), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'clear', array('entityName' => $entityName), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->clear($entityName);
    }

    public function close()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'close', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->close();
    }

    public function persist($entity)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'persist', array('entity' => $entity), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'remove', array('entity' => $entity), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'refresh', array('entity' => $entity), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'detach', array('entity' => $entity), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'merge', array('entity' => $entity), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getRepository', array('entityName' => $entityName), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'contains', array('entity' => $entity), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getEventManager', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getConfiguration', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'isOpen', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getUnitOfWork', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getProxyFactory', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'initializeObject', array('obj' => $obj), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'getFilters', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'isFiltersStateClean', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'hasFilters', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return $this->valueHolder5d13b->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializeraadb4 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder5d13b) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder5d13b = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder5d13b->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, '__get', ['name' => $name], $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        if (isset(self::$publicPropertiesd1f24[$name])) {
            return $this->valueHolder5d13b->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5d13b;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder5d13b;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, '__set', array('name' => $name, 'value' => $value), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5d13b;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder5d13b;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, '__isset', array('name' => $name), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5d13b;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder5d13b;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, '__unset', array('name' => $name), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5d13b;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder5d13b;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, '__clone', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        $this->valueHolder5d13b = clone $this->valueHolder5d13b;
    }

    public function __sleep()
    {
        $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, '__sleep', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;

        return array('valueHolder5d13b');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializeraadb4 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializeraadb4;
    }

    public function initializeProxy() : bool
    {
        return $this->initializeraadb4 && ($this->initializeraadb4->__invoke($valueHolder5d13b, $this, 'initializeProxy', array(), $this->initializeraadb4) || 1) && $this->valueHolder5d13b = $valueHolder5d13b;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder5d13b;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder5d13b;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
